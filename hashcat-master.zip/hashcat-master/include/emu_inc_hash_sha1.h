/**
 * Author......: See docs/credits.txt
 * License.....: MIT
 */

#ifndef HC_EMU_INC_HASH_SHA1_H
#define HC_EMU_INC_HASH_SHA1_H

#include "emu_general.h"

#include "inc_vendor.h"
#include "inc_hash_sha1.h"

#endif // HC_EMU_INC_HASH_SHA1_H
