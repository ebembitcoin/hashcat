/**
 * Author......: See docs/credits.txt
 * License.....: MIT
 */

#ifndef HC_AUTOTUNE_H
#define HC_AUTOTUNE_H

HC_API_CALL void *thread_autotune (void *p);

#endif // HC_AUTOTUNE_H
