/**
 * Author......: See docs/credits.txt
 * License.....: MIT
 */

#ifndef HC_EMU_INC_HASH_MD5_H
#define HC_EMU_INC_HASH_MD5_H

#include "emu_general.h"

#include "inc_vendor.h"
#include "inc_hash_md5.h"

#endif // HC_EMU_INC_HASH_MD5_H
