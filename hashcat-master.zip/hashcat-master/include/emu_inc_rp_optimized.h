/**
 * Author......: See docs/credits.txt
 * License.....: MIT
 */

#ifndef HC_EMU_INC_RP_OPTIMIZED_H
#define HC_EMU_INC_RP_OPTIMIZED_H

#include "emu_general.h"

#include "inc_vendor.h"
#include "inc_rp_optimized.h"

#endif // HC_EMU_INC_RP_OPTIMIZED_H
