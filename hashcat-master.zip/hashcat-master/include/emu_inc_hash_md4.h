/**
 * Author......: See docs/credits.txt
 * License.....: MIT
 */

#ifndef HC_EMU_INC_HASH_MD4_H
#define HC_EMU_INC_HASH_MD4_H

#include "emu_general.h"

#include "inc_vendor.h"
#include "inc_hash_md4.h"

#endif // HC_EMU_INC_HASH_MD4_H
